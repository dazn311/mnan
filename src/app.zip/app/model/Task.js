"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Task = void 0;
var Task = /** @class */ (function () {
    function Task(id, task, text, date, folder, userID) {
        this.id = id;
        this.task = task;
        this.text = text;
        this.date = date;
        this.folder = folder;
        this.userID = userID;
    }
    return Task;
}());
exports.Task = Task;
