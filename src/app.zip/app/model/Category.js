"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Category = void 0;
var Category = /** @class */ (function () {
    function Category(id, title, child) {
        this.id = id;
        this.title = title;
        this.child = child;
    }
    return Category;
}());
exports.Category = Category;
