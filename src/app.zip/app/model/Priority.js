"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Priority = void 0;
var Priority = /** @class */ (function () {
    function Priority(id, title, color) {
        this.id = id;
        this.title = title;
        this.color = color;
    }
    return Priority;
}());
exports.Priority = Priority;
