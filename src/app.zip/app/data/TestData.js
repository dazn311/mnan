"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TestData = void 0;
var TestData = /** @class */ (function () {
    function TestData() {
    }
    return TestData;
}());
exports.TestData = TestData;
