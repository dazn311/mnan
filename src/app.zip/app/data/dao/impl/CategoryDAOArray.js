"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CategoryDAOArray = void 0;
var CategoryDAOArray = /** @class */ (function () {
    function CategoryDAOArray() {
    }
    CategoryDAOArray.prototype.get = function (id) {
        return undefined;
    };
    CategoryDAOArray.prototype.getAll = function () {
        // return of(DataTablesService.tasks);
        return undefined;
    };
    CategoryDAOArray.prototype.add = function (category) {
        return undefined;
    };
    CategoryDAOArray.prototype.delete = function (id) {
        //   // перед удалением - нужно в задачах занулить все ссылки на удаленное значение
        //   // в реальной БД сама обновляет все ссылки (cascade update) - здесь нам приходится делать это вручную (т.к. вместо БД - массив)
        // DataTablesService.tasks.forEach(task => {
        //       if (task.folder && task.folder.id === id) {
        //           task.category = null;
        //       }
        //   });
        //
        //   const tmpCategory = DataTablesService.categories.find(t => t.id === id); // удаляем по id
        // DataTablesService.categories.splice(DataTablesService.categories.indexOf(tmpCategory), 1);
        //
        //   return of(tmpCategory);
        return undefined;
    };
    CategoryDAOArray.prototype.update = function (category) {
        //   const tmpCategory = DataTablesService.categories.find(t => t.id === category.id); // обновляем по id
        // DataTablesService.categories.splice(DataTablesService.categories.indexOf(tmpCategory), 1, category);
        //
        //   return of(tmpCategory);
        return undefined;
    };
    CategoryDAOArray.prototype.search = function (title) {
        return undefined;
    };
    return CategoryDAOArray;
}());
exports.CategoryDAOArray = CategoryDAOArray;
