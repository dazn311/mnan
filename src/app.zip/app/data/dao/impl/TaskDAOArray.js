"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TaskDAOArray = void 0;
var TaskDAOArray = /** @class */ (function () {
    function TaskDAOArray() {
    }
    TaskDAOArray.prototype.getAll = function () {
        // return of(TestData.tasks);
        return undefined;
    };
    TaskDAOArray.prototype.get = function (id) {
        return undefined;
    };
    TaskDAOArray.prototype.add = function (task) {
        // если id пустой - генерируем его
        // if (task.id === null || task.id === 0) {
        //     task.id = this.getLastIdTask();
        // }
        // TestData.tasks.push(task);
        //
        // return of(task);
        return undefined;
    };
    TaskDAOArray.prototype.delete = function (id) {
        // const taskTmp = TestData.tasks.find(t => t.id === id); // удаляем по id
        // TestData.tasks.splice(TestData.tasks.indexOf(taskTmp), 1);
        //
        // return of(taskTmp);
        return undefined;
    };
    TaskDAOArray.prototype.getCompletedCountInCategory = function (category) {
        return undefined;
    };
    TaskDAOArray.prototype.getTotalCount = function () {
        return undefined;
    };
    TaskDAOArray.prototype.getTotalCountInCategory = function (category) {
        return undefined;
    };
    TaskDAOArray.prototype.getUncompletedCountInCategory = function (category) {
        return undefined;
    };
    // если значение null - параметр не нужно учитывать при поиске
    TaskDAOArray.prototype.search = function (category, searchText, status, priority) {
        // return of(this.searchTasks(category, searchText, status, priority));
        return undefined;
    };
    // поиск задач по параметрам
    TaskDAOArray.prototype.update = function (task) {
        // const taskTmp = TestData.tasks.find(t => t.id === task.id); // обновляем по id
        // TestData.tasks.splice(TestData.tasks.indexOf(taskTmp), 1, task);
        //
        // return of(task);
        return undefined;
    };
    // находит последний id (чтобы потом вставить новую запись с id, увеличенным на 1) - в реальной БД это происходит автоматически
    TaskDAOArray.prototype.getLastIdTask = function () {
        // return Math.max.apply(Math, TestData.tasks.map(task => task.id)) + 1;
        return undefined;
    };
    TaskDAOArray.prototype.searchTasks = function (category, searchText, status, priority) {
        // let allTasks = TestData.tasks;
        //
        // // поочереди применяем все условия (какие не пустые)
        // if (status != null) {
        //     allTasks = allTasks.filter(task => task.completed === status);
        // }
        //
        // if (category != null) {
        //     allTasks = allTasks.filter(task => task.category === category);
        // }
        //
        // if (priority != null) {
        //     allTasks = allTasks.filter(task => task.priority === priority);
        // }
        //
        // if (searchText != null) {
        //     allTasks = allTasks.filter(
        //         task =>
        //             task.title.toUpperCase().includes(searchText.toUpperCase()) // учитываем текст поиска (если '' - возвращаются все значения)
        //     );
        // }
        //
        // return allTasks;
        return undefined;
    };
    return TaskDAOArray;
}());
exports.TaskDAOArray = TaskDAOArray;
