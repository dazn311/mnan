"use strict";
// стандартные методы CRUD (create, read, udpate, delete)
Object.defineProperty(exports, "__esModule", { value: true });
