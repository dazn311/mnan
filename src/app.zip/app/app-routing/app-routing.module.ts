import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {RouterModule, Routes} from '@angular/router';
import {AuthComponent} from '../companents/auth/auth.component';
import {TablesComponent} from '../companents/tables/tables.component';

const routes: Routes = [
  {path: '', component: AuthComponent},
  {path: 'tab', component: TablesComponent},
];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {
}
